import express from 'express';
import { authMiddleware } from '../../common/middleware/auth.middleware';
import { roleMiddleware } from '../../common/middleware/role.middleware';
import { asyncHandler } from '../../common/utils/asyncHandler';
import * as controller from './investor.controller';

const router = express.Router();
router.get('/profile', authMiddleware, roleMiddleware('INVESTOR'), asyncHandler(controller.profile));
export default router;
